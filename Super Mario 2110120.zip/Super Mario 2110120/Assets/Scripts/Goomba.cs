using System.Collections; // Required for IEnumerator
using UnityEngine;

public class Goomba : MonoBehaviour
{
    public Sprite flatSprite;
    public float speed = 2f; // Speed of movement
    public float changeDirectionTime = 2f; // Time interval for changing direction

    private Vector2 movementDirection;

    private void Start()
    {
        // Start random movement coroutine
        StartCoroutine(RandomMovement());
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.gameObject.TryGetComponent(out Player player))
        {
            if (player.starpower) {
                Hit();
            } else if (collision.transform.DotTest(transform, Vector2.down)) {
                Flatten();
            } else {
                player.Hit();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Shell")) {
            Hit();
        }
    }

    private void Flatten()
    {
        GetComponent<Collider2D>().enabled = false;
        GetComponent<EntityMovement>().enabled = false;
        GetComponent<AnimatedSprite>().enabled = false;
        GetComponent<SpriteRenderer>().sprite = flatSprite;
        Destroy(gameObject, 0.5f);
    }

    private void Hit()
    {
        GetComponent<AnimatedSprite>().enabled = false;
        GetComponent<DeathAnimation>().enabled = true;
        Destroy(gameObject, 3f);
    }

    private IEnumerator RandomMovement()
    {
        while (true)
        {
            // Choose a random direction
            movementDirection = Random.insideUnitCircle.normalized;

            // Move in that direction
            float moveDuration = Random.Range(1f, 3f); // Random duration for movement
            float elapsed = 0f;

            while (elapsed < moveDuration)
            {
                transform.Translate(movementDirection * speed * Time.deltaTime);
                elapsed += Time.deltaTime;
                yield return null;
            }

            // Wait before changing direction again
            yield return new WaitForSeconds(changeDirectionTime);
        }
    }
}
